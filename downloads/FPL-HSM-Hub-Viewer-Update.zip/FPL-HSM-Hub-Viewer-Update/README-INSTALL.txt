FPL HSM HUB — ROTATION UPDATE (2f27cbc)

JPG, PNG and PDF: left/right rotation in 90-degree steps, zoom and fit to screen.
PDF also has page navigation. Asal resets rotation and zoom.
Rotation is for the preview; your uploaded originals are not edited.

1. Keep a backup of your current Hub folder.
2. Copy public/, src/, tests/, apps-script/ and firebase.json from this update
   into your EXISTING Hub folder, replacing matching files/folders.
   Keep all public/assets/vendor/pdfjs/ files together, including licenses.
   Keep your existing config/ folder: this ZIP has NO config/ folder and leaves
   your customized config/local.json and application links untouched.
3. To enable PDF rotation, open your EXISTING FPL HSM Hub Uploads Apps Script
   project and replace its code with the complete apps-script/DriveUploads.gs
   included here. Keep its script properties and upload folder.
   Deploy > Manage deployments > Edit (pencil) > New version > Deploy.
   Retain the same deployment URL. Do not create a new project/folder.
4. In Terminal or PowerShell inside your existing Hub folder, run:
   npm run build
   firebase deploy --only hosting --project fpl-hsm-pharmacy-hub
5. Open the website and test JPG, PNG and a multi-page PDF. Use the curved arrow
   buttons to rotate, + / - to zoom, Muat skrin to fit and Asal to reset.

If Apps Script has not been updated or PDF rendering fails, PDFs fall back to
Google Drive preview without Hub rotation buttons. Images can rotate immediately.
The new public readPdf operation checks the published notice reference, folder,
file ownership marker and public view-only sharing before returning PDF bytes.
Uploads, replacement and deletion still require an enabled Firebase admin.

Your existing Firestore rules apply. No new Firebase project, firebase init,
npm dependency installation, Cloud Storage or billing upgrade is needed.
Previously uploaded files do not need uploading again.
Local rendering and authorization tests pass; the updated live Apps Script
endpoint and cross-origin PDF response must be checked after deployment.
