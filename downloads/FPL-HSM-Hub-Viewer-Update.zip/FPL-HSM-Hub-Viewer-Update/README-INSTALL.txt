FPL HSM HUB — VIEWER UPDATE (0a578df)

Click announcement attachments to view them inside the Hub.
JPG/PNG: zoom in/out, fit to screen, scroll enlarged content, up to 400%.
PDF: embedded Google Drive viewer with Google's zoom/page controls.
Existing uploaded files work without re-uploading.

UPDATE YOUR EXISTING FOLDER:
1. Keep a backup of your existing Hub folder.
2. Copy public/, src/, tests/ and firebase.json from this update into your EXISTING
   Hub folder, replacing the matching files/folders. The source folders are complete.
3. Leave your existing config/ folder in place. This ZIP has NO config/ folder,
   and does not replace config/local.json or your custom links/settings.
4. Open Terminal or PowerShell inside your existing Hub folder and run:
   npm run build
   firebase deploy --only hosting --project fpl-hsm-pharmacy-hub
5. Open the deployed site and click an existing attachment. Test image + / - /
   Muat skrin and the PDF viewer's built-in zoom/page controls on your devices.

Your existing Apps Script upload deployment and Firestore rules still apply.
No new Firebase project, firebase init, dependencies or billing upgrade is needed.
Local tests passed with simulated Google responses. The actual embedded Drive PDF
viewer and its toolbar still need checking after your Hosting deployment.
